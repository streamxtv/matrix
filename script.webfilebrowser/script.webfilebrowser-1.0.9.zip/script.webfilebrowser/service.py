# -*- coding: utf-8 -*-

from resources.lib.service import run
from resources.lib.utils import set_logger

# Configura o sistema de log e inicia o serviço de monitoramento
set_logger()
run()