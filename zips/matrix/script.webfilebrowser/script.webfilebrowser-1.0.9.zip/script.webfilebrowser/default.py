# -*- coding: utf-8 -*-

import xbmcaddon

# Abre diretamente a janela de configurações do add-on
xbmcaddon.Addon().openSettings()